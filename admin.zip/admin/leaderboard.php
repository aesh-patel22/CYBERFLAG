<?php
session_start();
require_once '../config/configdb.php';

/* ===============================
   AUTH CHECK
================================ */
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit;
}

/* ===============================
   HELPERS
================================ */
function parseTimeToSeconds($time) {
    if (preg_match('/^\d{2}:\d{2}$/', $time)) {
        [$m, $s] = explode(':', $time);
        return ((int)$m * 60) + (int)$s;
    }
    return null;
}

function formatSecondsToTime($seconds) {
    if (!$seconds) return 'N/A';
    return sprintf("%02d:%02d", floor($seconds / 60), $seconds % 60);
}

/* ===============================
   PAGINATION
================================ */
// Pagination defaults
$per_page = 10;
$page = 1;

// Validate per_page
if (isset($_GET['per_page']) && in_array((int)$_GET['per_page'], [5, 10, 20, 50])) {
    $per_page = (int)$_GET['per_page'];
}

// Validate page
if (isset($_GET['page']) && (int)$_GET['page'] > 0) {
    $page = (int)$_GET['page'];
}

$offset = ($page - 1) * $per_page;
/* ===============================
   TOTAL COUNT
================================ */
$total_scores = $pdo->query("SELECT COUNT(*) FROM tbl_user_score")->fetchColumn();
$total_pages = $total_scores > 0 
    ? max(1, ceil($total_scores / $per_page)) 
    : 1;
/* ===============================
   FETCH LEADERBOARD DATA
================================ */
$sql = "
SELECT 
    us.user_id,
    ud.user_name,
    us.total_point,
    us.c1, us.c2, us.c3, us.c4, us.c5,
    us.c6, us.c7, us.c8, us.c9, us.c10,
    us.c11, us.c12, us.c13, us.c14, us.c15,
    us.c16, us.c17, us.c18, us.c19, us.c20
FROM tbl_user_score us
LEFT JOIN tbl_user_detail ud ON us.user_id = ud.user_id
ORDER BY us.total_point DESC
LIMIT :limit OFFSET :offset
";

$stmt = $pdo->prepare($sql);
$stmt->bindValue(':limit', $per_page, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();

$raw_scores = $stmt->fetchAll(PDO::FETCH_ASSOC);

/* ===============================
   PROCESS SCORES
================================ */
$scores = [];

foreach ($raw_scores as $row) {
    $times = [];
    $solved = 0;

    for ($i = 1; $i <= 20; $i++) {
        $key = "c$i";
        if (!empty($row[$key])) {
            $sec = parseTimeToSeconds($row[$key]);
            if ($sec !== null) {
                $times[] = $sec;
                $solved++;
            }
        }
    }

    $row['solved_challenges'] = $solved;
    $row['average_time'] = !empty($times)
        ? formatSecondsToTime((int)(array_sum($times) / count($times)))
        : 'N/A';

    $scores[] = $row;
}

/* ===============================
   AJAX: FETCH SCORES
================================ */
if (isset($_GET['get_scores'])) {
    header('Content-Type: application/json');
    echo json_encode(['scores' => $scores]);
    exit;
}

/* ===============================
   AJAX: FETCH USER DETAILS
================================ */
if (isset($_GET['get_details'])) {
    $uid = (int)$_GET['get_details'];

    $stmt = $pdo->prepare("
        SELECT us.*, ud.user_name 
        FROM tbl_user_score us
        LEFT JOIN tbl_user_detail ud ON us.user_id = ud.user_id
        WHERE us.user_id = ?
    ");
    $stmt->execute([$uid]);
    $data = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($data) {
        $times = [];
        $solved = 0;

        for ($i = 1; $i <= 20; $i++) {
            if (!empty($data["c$i"])) {
                $sec = parseTimeToSeconds($data["c$i"]);
                if ($sec !== null) {
                    $times[] = $sec;
                    $solved++;
                }
            }
        }

        $data['solved_challenges'] = $solved;
        $data['average_time'] = !empty($times)
            ? formatSecondsToTime((int)(array_sum($times) / count($times)))
            : 'N/A';
    }

    header('Content-Type: application/json');
    echo json_encode($data ?: []);
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Leaderboard</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-slate-900 text-white p-6">

<div class="flex items-center justify-between mb-4">
    <h1 class="text-2xl font-bold">🏆 Leaderboard</h1>

    <a href="index.php"
       class="bg-blue-600 hover:bg-blue-700 transition px-4 py-2 rounded text-sm font-semibold flex items-center gap-2">
        ⬅ Go to Home
    </a>
</div>

<table class="w-full border border-slate-700">
<thead class="bg-slate-800">
<tr>
<th class="p-3">Rank</th>
<th class="p-3">User ID</th>
<th class="p-3">Name</th>
<th class="p-3">Points</th>
<th class="p-3">Avg Time</th>
<th class="p-3">Solved</th>
</tr>
</thead>

<tbody>
<?php if (empty($scores)): ?>
<tr><td colspan="6" class="p-4 text-center">No users found</td></tr>
<?php else: ?>
<?php $rank = $offset + 1; foreach ($scores as $s): ?>
<tr class="border-t border-slate-700 hover:bg-slate-800">
<td class="p-3"><?= $rank++ ?></td>
<td class="p-3"><?= htmlspecialchars($s['user_id']) ?></td>
<td class="p-3"><?= htmlspecialchars($s['user_name'] ?? 'N/A') ?></td>
<td class="p-3"><?= $s['total_point'] ?></td>
<td class="p-3"><?= $s['average_time'] ?></td>
<td class="p-3"><?= $s['solved_challenges'] ?>/20</td>
</tr>
<?php endforeach; ?>
<?php endif; ?>
</tbody>
</table>

<!-- PAGINATION -->
<div class="mt-6 flex gap-2">
<?php for ($i = 1; $i <= $total_pages; $i++): ?>
<a href="?page=<?= $i ?>&per_page=<?= $per_page ?>"
   class="px-3 py-1 border <?= $i == $page ? 'bg-blue-600' : 'bg-slate-800' ?>">
   <?= $i ?>
</a>
<?php endfor; ?>
</div>

</body>
</html>
