<?php
// timer.php
// Reusable timer logic for CTF challenges
// To be included in challenge pages (e.g., challenge1.php, challenge2.php)

// Requires: session_start() and configdb.php to be included in the parent script
// Parameters:
// - $challenge_number: The challenge number (1 to 20)
// - $pdo: PDO database connection from configdb.php
// - $user_id: $_SESSION['user_id']
// - &$challenge_completed: Boolean to track if challenge is completed (passed by reference)
// - &$user_points: Current user points (passed by reference)
// - &$feedback: Feedback message for flag submission (passed by reference)

// Check if challenge is completed
function checkChallengeStatus($pdo, $user_id, $challenge_number) {
    $column = "c$challenge_number";
    $stmt = $pdo->prepare("SELECT $column, total_point FROM tbl_user_score WHERE user_id = :user_id");
    $stmt->execute(['user_id' => $user_id]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return [
        'completed' => $result[$column] !== null,
        'points' => $result['total_point'] ?? 0
    ];
}

// Update challenge completion time (MM:SS) and points
function updateChallenge($pdo, $user_id, $challenge_number, $time_spent) {
    try {
        $pdo->beginTransaction();
        $column = "c$challenge_number";
        $stmt = $pdo->prepare("UPDATE tbl_user_score SET $column = :time_spent, total_point = total_point + 10 WHERE user_id = :user_id");
        $stmt->execute(['time_spent' => $time_spent, 'user_id' => $user_id]);
        $pdo->commit();
        return ['success' => true, 'points' => getUserPoints($pdo, $user_id)];
    } catch (PDOException $e) {
        $pdo->rollBack();
        error_log("Challenge update failed for c$challenge_number: " . $e->getMessage());
        return ['success' => false, 'error' => 'Could not update challenge status.'];
    }
}

// Get current user points
function getUserPoints($pdo, $user_id) {
    $stmt = $pdo->prepare("SELECT total_point FROM tbl_user_score WHERE user_id = :user_id");
    $stmt->execute(['user_id' => $user_id]);
    return $stmt->fetchColumn() ?? 0;
}
?>