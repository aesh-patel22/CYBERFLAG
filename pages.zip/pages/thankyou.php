<?php
// Start or resume session
session_start();

// Redirect to index.php if not logged in
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_name'])) {
    error_log("Session missing: user_id or user_name not set");
    header('Location: ../index.php');
    exit();
}

// Include secure database connection
require_once '../config/configdb.php';

// Initialize variables
$user_points = 0;
$challenge_number = 20;

// Check if Challenge 20 is completed
try {
    $stmt = $pdo->prepare("SELECT c20, total_point FROM tbl_user_score WHERE user_id = :user_id");
    $stmt->execute(['user_id' => $_SESSION['user_id']]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($result['c20'] === null) {
        $_SESSION['feedback'] = "Complete Challenge 20 first!";
        $_SESSION['feedback_color'] = '#ff6666';
        header('Location: challenge20.php');
        exit();
    }
    $user_points = $result['total_point'] ?? 0;
} catch (PDOException $e) {
    error_log("Error checking Challenge 20 status: " . $e->getMessage());
    $_SESSION['feedback'] = "Error: Could not verify Challenge 20 completion.";
    $_SESSION['feedback_color'] = '#ff6666';
    header('Location: challenge20.php');
    exit();
}

// Check if current challenge is allowed
if (!isset($_SESSION['challenge_no']) || $challenge_number >= $_SESSION['challenge_no']) {
    $_SESSION['feedback'] = "Access denied: Complete Challenge 20 first.";
    $_SESSION['feedback_color'] = '#ff6666';
    header('Location: challenge20.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CYBERFLAG :: Mission Complete</title>
    <!-- <script src="https://cdn.tailwindcss.com"></script> -->
    <style>
        /* @import url('https://fonts.googleapis.com/css2?family=Share+Tech+Mono:wght@400&display=swap'); */

        @font-face {
            font-family: 'Share Tech Mono';
            src: url('../fonts/ShareTechMono-Regular.ttf') format('woff2');
            font-weight: 400;
            font-style: normal;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Share Tech Mono', monospace;
            background: #000000;
            color: #00ff00;
            overflow-x: hidden;
        }

        .hacker-bg {
            background:
                radial-gradient(circle at 30% 40%, rgba(0, 255, 0, 0.06) 0%, transparent 40%),
                radial-gradient(circle at 70% 30%, rgba(0, 255, 255, 0.04) 0%, transparent 40%),
                linear-gradient(180deg, #000000 0%, #001a00 50%, #000000 100%);
            background-size: 100% 100%;
            animation: backgroundShift 20s ease-in-out infinite;
        }

        @keyframes backgroundShift {
            0%, 100% { background-position: 0% 0%, 0% 0%, 0% 0%; }
            50% { background-position: 30% 30%, 70% 70%, 0% 0%; }
        }

        .matrix-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            pointer-events: none;
            z-index: 1;
            opacity: 0.1;
            background: repeating-linear-gradient(
                0deg,
                transparent,
                transparent 3px,
                rgba(0, 255, 0, 0.02) 3px,
                rgba(0, 255, 0, 0.02) 5px
            );
            animation: matrixScroll 25s linear infinite;
        }

        @keyframes matrixScroll {
            0% { transform: translateY(0); }
            100% { transform: translateY(120px); }
        }

        .terminal-glow {
            box-shadow:
                0 0 15px rgba(0, 255, 0, 0.4),
                0 0 30px rgba(0, 255, 0, 0.2),
                inset 0 0 15px rgba(0, 255, 0, 0.05);
            border: 2px solid #00ff00;
            background: rgba(0, 0, 0, 0.85);
        }

        .terminal-scan::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 2px;
            background: linear-gradient(90deg, transparent, #00ff00, transparent);
            animation: terminalScan 4s infinite;
        }

        @keyframes terminalScan {
            0% { left: -100%; }
            100% { left: 100%; }
        }

        .hack-button {
            background: linear-gradient(45deg, #000000, #001a00);
            border: 2px solid #00ff00;
            box-shadow: 0 0 8px #00ff00;
            transition: all 0.3s ease;
        }

        .hack-button:hover {
            box-shadow: 0 0 25px #00ff00;
            transform: scale(1.03);
        }

        .glitch-text {
            position: relative;
            animation: glitch 1.5s infinite;
        }

        .glitch-text::before,
        .glitch-text::after {
            content: attr(data-text);
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
        }

        .glitch-text::before {
            animation: glitch-red 0.4s infinite;
            color: #ff0000;
            z-index: -1;
        }

        .glitch-text::after {
            animation: glitch-blue 0.4s infinite;
            color: #00ccff;
            z-index: -2;
        }

        @keyframes glitch {
            0%, 100% { transform: translate(0); }
            20% { transform: translate(-1px, -1px); }
            40% { transform: translate(1px, 1px); }
            60% { transform: translate(-1px, 1px); }
            80% { transform: translate(1px, -1px); }
        }

        @keyframes glitch-red {
            0%, 100% { transform: translate(0); }
            20% { transform: translate(-1px, -1px); }
            40% { transform: translate(1px, 1px); }
            60% { transform: translate(-1px, 1px); }
            80% { transform: translate(1px, -1px); }
        }

        @keyframes glitch-blue {
            0%, 100% { transform: translate(0); }
            20% { transform: translate(1px, 1px); }
            40% { transform: translate(-1px, -1px); }
            60% { transform: translate(1px, -1px); }
            80% { transform: translate(-1px, 1px); }
        }

        .success-message {
            border: 2px solid #00ff88;
            background: rgba(0, 255, 136, 0.1);
        }
    </style>
    <link href="../tailwind.min.css" rel="stylesheet"></link>
</head>
<body class="hacker-bg min-h-screen">
    <!-- Matrix Overlay -->
    <div class="matrix-overlay"></div>

    <!-- Main Container -->
    <div class="min-h-screen flex items-center justify-center p-8">
        <div class="terminal-glow rounded-lg w-full max-w-3xl p-10 terminal-scan relative">
            <!-- Header -->
            <div class="flex justify-between items-center mb-6 pb-4 border-b border-green-500">
                <div class="flex items-center space-x-3">
                    <div class="w-8 h-8 bg-red-500 rounded-full animate-pulse"></div>
                    <div>
                        <h1 class="glitch-text text-3xl font-bold text-green-400" data-text="MISSION COMPLETE">MISSION COMPLETE</h1>
                        <div class="text-green-300 text-sm">CYBERFLAG CTF</div>
                    </div>
                </div>
                <div class="text-right">
                    <div class="text-red-400 font-mono text-sm" id="systemTime">00:00:00</div>
                    <div class="text-green-300 text-xs">SYSTEM TIME</div>
                </div>
            </div>

            <!-- Points -->
            <div class="flex justify-between mb-6 text-green-400 font-mono">
                <div>Points: <span id="userPoints"><?php echo htmlspecialchars($user_points); ?></span></div>
            </div>

            <!-- Completion Message -->
            <div class="mb-6">
                <h2 class="text-2xl text-green-400 mb-4">Congratulations, <?php echo htmlspecialchars($_SESSION['user_name']); ?>!</h2>
                <p class="text-green-300">You have successfully completed the CYBERFLAG CTF! Your skills in decoding, logic, and persistence have paid off.</p>
                <p class="text-green-300 mt-2">Total Points Earned: <span class="text-cyan-400"><?php echo htmlspecialchars($user_points); ?></span></p>
            </div>

            <!-- Success Message -->
            <div class="success-message rounded-lg p-4 mt-6">
                <p class="font-mono text-green-400">🎉 CTF Conquered! Thank you for participating in CYBERFLAG CTF.</p>
            </div>

            <!-- Return to Home -->
            <div class="mt-6 text-center">
                <a href="../index.php" class="hack-button inline-block px-6 py-3 rounded-lg font-bold text-green-400">← Return to Home</a>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <div class="fixed bottom-0 left-0 right-0 bg-black bg-opacity-80 border-t border-green-500 p-4 z-20">
        <div class="flex justify-between items-center text-green-400 font-mono text-sm">
            <div>© 2025 CYBERFLAG CTF</div>
            <div class="flex space-x-4">
                <span>USER: <span class="text-cyan-400"><?php echo htmlspecialchars($_SESSION['user_name']); ?></span></span>
                <span>STATUS: <span class="text-red-400">VICTORIOUS</span></span>
            </div>
        </div>
    </div>

    <script>
        // System time
        function updateSystemTime() {
            const now = new Date();
            document.getElementById('systemTime').textContent = now.toLocaleTimeString('en-US', {
                hour12: false,
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit'
            });
        }

        // Initialize
        setInterval(updateSystemTime, 1000);
    </script>
</body>
</html>
