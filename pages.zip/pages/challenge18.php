<?php
// Start or resume session
session_start();

// Redirect to index.php if not logged in
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_name'])) {
    error_log("Session missing: user_id or user_name not set");
    header('Location: ../index.php');
    exit();
}

// Include secure database connection and timer logic
require_once '../config/configdb.php';
require_once 'timer.php';

// Initialize variables
$feedback = isset($_SESSION['feedback']) ? $_SESSION['feedback'] : '';
$feedback_color = isset($_SESSION['feedback_color']) ? $_SESSION['feedback_color'] : '#ff6666';
unset($_SESSION['feedback'], $_SESSION['feedback_color']);
$challenge_completed = false;
$user_points = 0;
$challenge_number = 18;
$initial_seconds = 0;

// Check if Challenge 17 is completed
try {
    $stmt = $pdo->prepare("SELECT c17 FROM tbl_user_score WHERE user_id = :user_id");
    $stmt->execute(['user_id' => $_SESSION['user_id']]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($result['c17'] === null) {
        $_SESSION['feedback'] = "Complete Challenge 17 first!";
        $_SESSION['feedback_color'] = '#ff6666';
        header('Location: challenge17.php');
        exit();
    }
} catch (PDOException $e) {
    error_log("Error checking Challenge 17 status: " . $e->getMessage());
    $feedback = "Error: Could not verify Challenge 17 completion.";
    $feedback_color = '#ff6666';
}

// Check if current challenge is allowed
if (!isset($_SESSION['challenge_no']) || $challenge_number > $_SESSION['challenge_no']) {
    $_SESSION['feedback'] = "Access denied: Complete previous challenges first.";
    $_SESSION['feedback_color'] = '#ff6666';
    header("Location: challenge" . ($_SESSION['challenge_no'] ?? 1) . ".php");
    exit();
}

// Check if challenge is already completed
$status = checkChallengeStatus($pdo, $_SESSION['user_id'], $challenge_number);
$challenge_completed = $status['completed'];
$user_points = $status['points'];

// Initialize timer start
if (!$challenge_completed && !isset($_SESSION['timer_start_c18'])) {
    $_SESSION['timer_start_c18'] = time();
} elseif (!$challenge_completed) {
    $initial_seconds = time() - $_SESSION['timer_start_c18'];
}

// Get stored time if completed
$stored_time = '00:00';
if ($challenge_completed) {
    try {
        $stmt = $pdo->prepare("SELECT c18 FROM tbl_user_score WHERE user_id = :user_id");
        $stmt->execute(['user_id' => $_SESSION['user_id']]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        $stored_time = $result['c18'] ?? '00:00';
        if ($result['c18'] === null) {
            error_log("No time stored in tbl_user_score.c18 for user_id: " . $_SESSION['user_id']);
        }
    } catch (PDOException $e) {
        error_log("Error fetching stored time: " . $e->getMessage());
        $feedback = "Error: Could not retrieve stored time.";
        $feedback_color = '#ff6666';
    }
}

// Handle AJAX submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && !$challenge_completed) {
    header('Content-Type: application/json');
    $input = json_decode(file_get_contents('php://input'), true);
    $grid = isset($input['grid']) ? $input['grid'] : [];
    $time_spent = isset($input['time_spent']) ? filter_var($input['time_spent'], FILTER_SANITIZE_STRING) : '';

    if (!is_array($grid) || count($grid) !== 9 || !preg_match('/^\d{2}:\d{2}$/', $time_spent)) {
        echo json_encode(['success' => false, 'message' => 'Invalid grid or time format', 'color' => '#ff6666']);
        exit();
    }

    $correct_grid_base64 = 'MTAxMTEwMDEx';
    $correct_grid = array_map('intval', str_split(base64_decode($correct_grid_base64)));
    $constraints = [
        [0, 1, 2],// Rows
        [3, 4, 5], 
        [6, 7, 8], 
        // Columns
        [0, 3, 6], 
        [1, 4, 7], 
        [2, 5, 8]  
    ];
    $constraints_satisfied = true;
    foreach ($constraints as $group) {
        $sum = array_sum(array_intersect_key($grid, array_flip($group)));
        if ($sum % 2 !== 0) {
            $constraints_satisfied = false;
            break;
        }
    }

    if ($grid === $correct_grid && $constraints_satisfied) {
        $result = updateChallenge($pdo, $_SESSION['user_id'], $challenge_number, $time_spent);
        if ($result['success']) {
            $_SESSION['challenge_no'] = max($_SESSION['challenge_no'] ?? 18, 19); // Unlock Challenge 19
            unset($_SESSION['timer_start_c18']);
            echo json_encode([
                'success' => true,
                'message' => '🎉 Puzzle solved! Correct grid: [1,0,1,1,1,0,0,1,1]',
                'color' => '#00ff88',
                'points' => $result['points'],
                'correct_grid' => $correct_grid
            ]);
        } else {
            echo json_encode(['success' => false, 'message' => $result['error'], 'color' => '#ff6666']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => '❌ Incorrect grid. Ensure all rows and columns sum to even numbers.', 'color' => '#ff6666']);
    }
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CYBERFLAG :: Challenge 18</title>
    <link href="../tailwind.min.css" rel="stylesheet">
    <style>
        @font-face {
            font-family: 'Share Tech Mono';
            src: url('../fonts/ShareTechMono-Regular.ttf') format('woff2');
            font-weight: 400;
            font-style: normal;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Share Tech Mono', monospace;
            background: #000000;
            color: #00ff00;
            overflow-x: hidden;
        }

        .hacker-bg {
            background: 
                radial-gradient(circle at 30% 40%, rgba(0, 255, 0, 0.06) 0%, transparent 40%),
                radial-gradient(circle at 70% 30%, rgba(0, 255, 255, 0.04) 0%, transparent 40%),
                linear-gradient(180deg, #000000 0%, #001a00 50%, #000000 100%);
            background-size: 100% 100%;
            animation: backgroundShift 20s ease-in-out infinite;
        }

        @keyframes backgroundShift {
            0%, 100% { background-position: 0% 0%, 0% 0%, 0% 0%; }
            50% { background-position: 30% 30%, 70% 70%, 0% 0%; }
        }

        .matrix-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            pointer-events: none;
            z-index: 1;
            opacity: 0.1;
            background: repeating-linear-gradient(
                0deg,
                transparent,
                transparent 3px,
                rgba(0, 255, 0, 0.02) 3px,
                rgba(0, 255, 0, 0.02) 5px
            );
            animation: matrixScroll 25s linear infinite;
        }

        @keyframes matrixScroll {
            0% { transform: translateY(0); }
            100% { transform: translateY(120px); }
        }

        .terminal-glow {
            box-shadow: 
                0 0 15px rgba(0, 255, 0, 0.4),
                0 0 30px rgba(0, 255, 0, 0.2),
                inset 0 0 15px rgba(0, 255, 0, 0.05);
            border: 2px solid #00ff00;
            background: rgba(0, 0, 0, 0.85);
        }

        .terminal-scan::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 2px;
            background: linear-gradient(90deg, transparent, #00ff00, transparent);
            animation: terminalScan 4s infinite;
        }

        @keyframes terminalScan {
            0% { left: -100%; }
            100% { left: 100%; }
        }

        .hack-button {
            background: linear-gradient(45deg, #000000, #001a00);
            border: 2px solid #00ff00;
            box-shadow: 0 0 8px #00ff00;
            transition: all 0.3s ease;
        }

        .hack-button:hover {
            box-shadow: 0 0 25px #00ff00;
            transform: scale(1.03);
        }

        .hack-button:disabled {
            background: #333333;
            border-color: #666666;
            color: #666666;
            cursor: not-allowed;
            box-shadow: none;
        }

        .hack-cell {
            width: 80px;
            height: 80px;
            background: #001500;
            border: 2px solid #00ff00;
            color: #00ff00;
            font-size: 2rem;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.2s ease;
        }

        .hack-cell:hover {
            background: #003300;
            box-shadow: 0 0 8px #00ff00;
        }

        .hack-cell.disabled {
            cursor: not-allowed;
            background: #222222;
            color: #666666;
            border-color: #666666;
        }

        .grid {
            display: grid;
            grid-template-columns: repeat(3, 80px);
            gap: 10px;
            justify-content: center;
            margin-top: 20px;
        }

        .glitch-text {
            position: relative;
            animation: glitch 1.5s infinite;
        }

        .glitch-text::before,
        .glitch-text::after {
            content: attr(data-text);
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
        }

        .glitch-text::before {
            animation: glitch-red 0.4s infinite;
            color: #ff0000;
            z-index: -1;
        }

        .glitch-text::after {
            animation: glitch-blue 0.4s infinite;
            color: #00ccff;
            z-index: -2;
        }

        @keyframes glitch {
            0%, 100% { transform: translate(0); }
            20% { transform: translate(-1px, -1px); }
            40% { transform: translate(1px, 1px); }
            60% { transform: translate(-1px, 1px); }
            80% { transform: translate(1px, -1px); }
        }

        @keyframes glitch-red {
            0%, 100% { transform: translate(0); }
            20% { transform: translate(-1px, -1px); }
            40% { transform: translate(1px, 1px); }
            60% { transform: translate(-1px, 1px); }
            80% { transform: translate(1px, -1px); }
        }

        @keyframes glitch-blue {
            0%, 100% { transform: translate(0); }
            20% { transform: translate(1px, 1px); }
            40% { transform: translate(-1px, -1px); }
            60% { transform: translate(1px, -1px); }
            80% { transform: translate(-1px, 1px); }
        }

        .error-message {
            border: 2px solid #ff0000;
            background: rgba(255, 0, 0, 0.1);
        }

        .success-message {
            border: 2px solid #00ff88;
            background: rgba(0, 255, 136, 0.1);
        }

        .info-box {
            background: rgba(0, 0, 0, 0.6);
            border-left: 4px solid #00ff00;
            padding: 10px 20px;
            margin: 20px 0;
            color: #00ff00;
            border-radius: 5px;
        }
    </style>
</head>
<body class="hacker-bg min-h-screen">
    <!-- Matrix Overlay -->
    <div class="matrix-overlay"></div>

    <!-- Main Container -->
    <div class="min-h-screen flex items-center justify-center p-8">
        <div class="terminal-glow rounded-lg w-full max-w-3xl p-10 terminal-scan relative">
            <!-- Header -->
            <div class="flex justify-between items-center mb-6 pb-4 border-b border-green-500">
                <div class="flex items-center space-x-3">
                    <div class="w-8 h-8 bg-red-500 rounded-full animate-pulse"></div>
                    <div>
                        <h1 class="glitch-text text-3xl font-bold text-green-400" data-text="CHALLENGE 18">CHALLENGE 18</h1>
                        <div class="text-green-300 text-sm">CYBERFLAG CTF</div>
                    </div>
                </div>
                <div class="text-right">
                    <div class="text-red-400 font-mono text-sm" id="systemTime">00:00:00</div>
                    <div class="text-green-300 text-xs">SYSTEM TIME</div>
                </div>
            </div>

            <!-- Timer and Points -->
            <div class="flex justify-between mb-6 text-green-400 font-mono">
                <div>Points: <span id="userPoints"><?php echo htmlspecialchars($user_points); ?></span></div>
                <div>🕒 Challenge Timer: <span id="challengeTimer"><?php echo htmlspecialchars($stored_time); ?></span></div>
            </div>

            <!-- Challenge Description -->
            <div class="mb-6">
                <h2 class="text-2xl text-green-400 mb-4">Quantum Puzzle – Collapse the Qubits!</h2>
                <p class="text-green-300">Hello, <?php echo htmlspecialchars($_SESSION['user_name']); ?>. Toggle the grid cells (0 or 1) so that each row and column sums to an even number.</p>
                <p class="text-green-300">Check the console for the encoded solution.</p>
            </div>

            <!-- Hints -->
            <div class="info-box">
                <h3 class="text-lg text-green-400 mb-2">Hacker's Tips</h3>
                <ul class="space-y-2 text-green-300">
                    <li class="flex items-center space-x-2">
                        <span class="text-red-400">></span>
                        <span>Check the console for the Base64-encoded grid: <code>MTAxMTEwMDEx</code>.</span>
                    </li>
                    <li class="flex items-center space-x-2">
                        <span class="text-red-400">></span>
                        <span>Ensure each row and column sums to an even number.</span>
                    </li>
                    <li class="flex items-center space-x-2">
                        <span class="text-red-400">></span>
                        <span>Click cells to toggle between 0 and 1, then submit.</span>
                    </li>
                </ul>
            </div>

            <!-- Grid -->
            <div class="grid" id="grid"></div>

            <!-- Submit Button -->
            <div class="mt-6 flex flex-col items-center w-full max-w-md mx-auto">
                <!-- Submit Button -->
                <button id="submitButton" 
                        class="hack-button px-6 py-3 rounded-lg font-bold text-white bg-green-400 hover:bg-green-500 focus:outline-none focus:ring-2 focus:ring-green-300 disabled:bg-gray-300 disabled:text-gray-500 disabled:cursor-not-allowed transition-all duration-200" 
                        <?php echo $challenge_completed ? 'disabled' : ''; ?>>
                    Submit Puzzle
                </button>

                <!-- Feedback Section -->
                <?php if ($feedback): ?>
                    <div id="submitFeedback" class="rounded-lg p-4 mt-6 w-full <?php echo $feedback_color === '#00ff88' ? 'success-message' : 'error-message'; ?>">
                        <p class="font-mono text-center"><?php echo htmlspecialchars($feedback); ?></p>
                    </div>
                <?php else: ?>
                    <div id="submitFeedback" class="error-message rounded-lg p-4 mt-6 hidden w-full">
                        <p class="font-mono text-center"></p>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Next Challenge Link -->
            <div id="nextChallenge" class="mt-6 text-center <?php echo $challenge_completed ? '' : 'hidden'; ?>">
                <a href="challenge19.php" class="hack-button inline-block px-6 py-3 rounded-lg font-bold text-green-400">→ Proceed to Challenge 19</a>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <div class="fixed bottom-0 left-0 right-0 bg-black bg-opacity-80 border-t border-green-500 p-4 z-20">
        <div class="flex justify-between items-center text-green-400 font-mono text-sm">
            <div>© 2025 CYBERFLAG CTF</div>
            <div class="flex space-x-4">
                <span>USER: <span class="text-cyan-400"><?php echo htmlspecialchars($_SESSION['user_name']); ?></span></span>
                <span>STATUS: <span class="text-red-400">ACTIVE</span></span>
            </div>
        </div>
    </div>

    <script>
        // Console hint
        console.log("💡 Tip: Decode the Base64 string 'MTAxMTEwMDEx' using atob() to get the 9-digit grid. Set the grid to match and ensure all rows and columns sum to even numbers.");

        // System time
        function updateSystemTime() {
            const now = new Date();
            document.getElementById('systemTime').textContent = now.toLocaleTimeString('en-US', {
                hour12: false,
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit'
            });
        }

        // Challenge timer
        let secondsSpent = <?php echo json_encode($initial_seconds); ?>;
        const challengeTimerDisplay = document.getElementById('challengeTimer');
        let timerRunning = <?php echo json_encode($challenge_completed); ?> ? false : true;
        let timerInterval = null;

        function updateTimer() {
            if (!timerRunning) return;
            secondsSpent++;
            const mins = Math.floor(secondsSpent / 60);
            const secs = secondsSpent % 60;
            const formattedTime = `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
            challengeTimerDisplay.textContent = formattedTime;
        }

        // Grid setup
        const gridEl = document.getElementById("grid");
        let userGrid = Array(9).fill(0);
        const isCompleted = <?php echo json_encode($challenge_completed); ?>;

        function setupGrid() {
            gridEl.innerHTML = "";
            for (let i = 0; i < 9; i++) {
                const cell = document.createElement("div");
                cell.className = isCompleted ? "hack-cell disabled" : "hack-cell";
                cell.textContent = userGrid[i];
                if (!isCompleted) {
                    cell.addEventListener("click", () => {
                        userGrid[i] = userGrid[i] === 0 ? 1 : 0;
                        cell.textContent = userGrid[i];
                    });
                }
                gridEl.appendChild(cell);
            }
        }

        // Constraints for client-side feedback
        const constraints = [
            [0, 1, 2], [3, 4, 5], [6, 7, 8], // Rows
            [0, 3, 6], [1, 4, 7], [2, 5, 8]  // Columns
        ];

        function checkConstraints() {
            return constraints.every(group => {
                const sum = group.reduce((acc, idx) => acc + userGrid[idx], 0);
                return sum % 2 === 0;
            });
        }

        // Form submission
        const submitButton = document.getElementById('submitButton');
        const submitFeedback = document.getElementById('submitFeedback');
        const feedbackText = submitFeedback.querySelector('p');
        const nextChallenge = document.getElementById('nextChallenge');

        if (!isCompleted) {
            submitButton.addEventListener('click', () => {
                if (!timerRunning) return;
                const timeSpent = challengeTimerDisplay.textContent;

                fetch('challenge18.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ grid: userGrid, time_spent: timeSpent })
                })
                .then(response => response.json())
                .then(data => {
                    submitFeedback.className = data.color === '#00ff88' ? 'success-message rounded-lg p-4 mt-6' : 'error-message rounded-lg p-4 mt-6';
                    feedbackText.style.color = data.color;
                    feedbackText.textContent = data.message;
                    submitFeedback.classList.remove('hidden');

                    if (data.success) {
                        timerRunning = false;
                        clearInterval(timerInterval);
                        document.getElementById('userPoints').textContent = data.points;
                        nextChallenge.classList.remove('hidden');
                        submitButton.disabled = true;
                        if (data.correct_grid) {
                            userGrid = data.correct_grid;
                            setupGrid();
                            document.querySelectorAll('.hack-cell').forEach(cell => {
                                cell.className = 'hack-cell disabled';
                                cell.style.pointerEvents = 'none';
                            });
                        }
                    }
                })
                .catch(error => {
                    console.error('Fetch error:', error);
                    submitFeedback.className = 'error-message rounded-lg p-4 mt-6';
                    feedbackText.style.color = '#ff6666';
                    feedbackText.textContent = 'Error: Could not process submission.';
                    submitFeedback.classList.remove('hidden');
                });
            });
        }

        // Initialize
        setInterval(updateSystemTime, 1000);
        if (timerRunning) {
            timerInterval = setInterval(updateTimer, 1000);
        }
        setupGrid();

        // Stop timer on page unload
        window.addEventListener('unload', () => {
            if (timerRunning) {
                timerRunning = false;
                clearInterval(timerInterval);
            }
        });
    </script>
</body>
</html>