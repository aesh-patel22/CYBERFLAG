<?php
// Start or resume session
session_start();

// Redirect to index.php if not logged in
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_name'])) {
    error_log("Session missing: user_id or user_name not set");
    header('Location: ../index.php');
    exit();
}

// Include secure database connection and timer logic
require_once '../config/configdb.php';
require_once 'timer.php';

// Initialize variables
$feedback = isset($_SESSION['feedback']) ? $_SESSION['feedback'] : '';
$feedback_color = isset($_SESSION['feedback_color']) ? $_SESSION['feedback_color'] : '#ff6666';
unset($_SESSION['feedback'], $_SESSION['feedback_color']);
$challenge_completed = false;
$user_points = 0;
$challenge_number = 8;
$initial_seconds = 0;

// Check if Challenge 7 is completed
try {
    $stmt = $pdo->prepare("SELECT c7 FROM tbl_user_score WHERE user_id = :user_id");
    $stmt->execute(['user_id' => $_SESSION['user_id']]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($result['c7'] === null) {
        $_SESSION['feedback'] = "Complete Challenge 7 first!";
        $_SESSION['feedback_color'] = '#ff6666';
        header('Location: challenge7.php');
        exit();
    }
} catch (PDOException $e) {
    error_log("Error checking Challenge 7 status: " . $e->getMessage());
    $_SESSION['feedback'] = "Error: Could not verify Challenge 7 completion.";
    $_SESSION['feedback_color'] = '#ff6666';
    header('Location: challenge7.php');
    exit();
}

// Check if current challenge is allowed
if (!isset($_SESSION['challenge_no']) || $challenge_number > $_SESSION['challenge_no']) {
    $_SESSION['feedback'] = "Access denied: Complete previous challenges first.";
    $_SESSION['feedback_color'] = '#ff6666';
    header("Location: challenge" . ($_SESSION['challenge_no'] ?? 7) . ".php");
    exit();
}

// Check if challenge is already completed
$status = checkChallengeStatus($pdo, $_SESSION['user_id'], $challenge_number);
$challenge_completed = $status['completed'];
$user_points = $status['points'];

// Initialize timer start
if (!$challenge_completed && !isset($_SESSION['timer_start_c8'])) {
    $_SESSION['timer_start_c8'] = time();
} elseif (!$challenge_completed) {
    $initial_seconds = time() - $_SESSION['timer_start_c8'];
}

// Correct sequence and flag
$correct_sequence = "IzQ2NDk0NiwjNDEzZDNkLCMzZDQxM2QsIzY2NjY2Ng==";
$hidden_flag = "Q1RGe0hpZGRlbl9pbl9DU1N9";

// Decode the correct sequence for comparison
$decoded_sequence = base64_decode($correct_sequence); // Decodes to #464946,#413d3d,#3d413d,#666666

// Handle AJAX submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && !$challenge_completed) {
    header('Content-Type: application/json');
    $input = json_decode(file_get_contents('php://input'), true);
    $answer = isset($input['answer']) ? trim(filter_var($input['answer'], FILTER_SANITIZE_STRING)) : '';
    $time_spent = isset($input['time_spent']) ? filter_var($input['time_spent'], FILTER_SANITIZE_STRING) : '';

    if (empty($answer) || !preg_match('/^\d{2}:\d{2}$/', $time_spent)) {
        echo json_encode(['success' => false, 'message' => 'Invalid sequence or time format', 'color' => '#ff6666']);
        exit();
    }

    try {
        if ($answer === $decoded_sequence) {
            $result = updateChallenge($pdo, $_SESSION['user_id'], $challenge_number, $time_spent);
            if ($result['success']) {
                $_SESSION['challenge_no'] = 9; // Unlock Challenge 9
                unset($_SESSION['timer_start_c8']);
                echo json_encode([
                    'success' => true,
                    'message' => "🎉 Correct sequence! Flag: $hidden_flag",
                    'color' => '#00ff88',
                    'points' => $result['points']
                ]);
            } else {
                echo json_encode(['success' => false, 'message' => $result['error'], 'color' => '#ff6666']);
            }
        } else {
            echo json_encode(['success' => false, 'message' => '❌ Incorrect sequence. Try again.', 'color' => '#ff6666']);
        }
    } catch (Exception $e) {
        error_log("Sequence verification failed: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Error: Could not verify sequence.', 'color' => '#ff6666']);
    }
    exit();
}

// Get stored time if completed
$stored_time = '00:00';
if ($challenge_completed) {
    try {
        $stmt = $pdo->prepare("SELECT c8 FROM tbl_user_score WHERE user_id = :user_id");
        $stmt->execute(['user_id' => $_SESSION['user_id']]); // Fixed: Added missing parenthesis
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        $stored_time = $result['c8'] ?? '00:00';
    } catch (PDOException $e) {
        error_log("Error fetching stored time: " . $e->getMessage());
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CYBERFLAG :: Challenge 8</title>
    <link href="../tailwind.min.css" rel="stylesheet">
    <style>
        @font-face {
            font-family: 'Share Tech Mono';
            src: url('../fonts/ShareTechMono-Regular.ttf') format('woff2');
            font-weight: 400;
            font-style: normal;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Share Tech Mono', monospace;
            background: #000000;
            color: #00ff00;
            overflow-x: hidden;
        }

        .hacker-bg {
            background: 
                radial-gradient(circle at 30% 40%, rgba(0, 255, 0, 0.06) 0%, transparent 40%),
                radial-gradient(circle at 70% 30%, rgba(0, 255, 255, 0.04) 0%, transparent 40%),
                linear-gradient(180deg, #000000 0%, #001a00 50%, #000000 100%);
            background-size: 100% 100%;
            animation: backgroundShift 20s ease-in-out infinite;
        }

        @keyframes backgroundShift {
            0%, 100% { background-position: 0% 0%, 0% 0%, 0% 0%; }
            50% { background-position: 30% 30%, 70% 70%, 0% 0%; }
        }

        .matrix-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            pointer-events: none;
            z-index: 1;
            opacity: 0.1;
            background: repeating-linear-gradient(
                0deg,
                transparent,
                transparent 3px,
                rgba(0, 255, 0, 0.02) 3px,
                rgba(0, 255, 0, 0.02) 5px
            );
            animation: matrixScroll 25s linear infinite;
        }

        @keyframes matrixScroll {
            0% { transform: translateY(0); }
            100% { transform: translateY(120px); }
        }

        .terminal-glow {
            box-shadow: 
                0 0 15px rgba(0, 255, 0, 0.4),
                0 0 30px rgba(0, 255, 0, 0.2),
                inset 0 0 15px rgba(0, 255, 0, 0.05);
            border: 2px solid #00ff00;
            background: rgba(0, 0, 0, 0.85);
        }

        .terminal-scan::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 2px;
            background: linear-gradient(90deg, transparent, #00ff00, transparent);
            animation: terminalScan 4s infinite;
        }

        @keyframes terminalScan {
            0% { left: -100%; }
            100% { left: 100%; }
        }

        .hack-button {
            background: linear-gradient(45deg, #000000, #001a00);
            border: 2px solid #00ff00;
            box-shadow: 0 0 8px #00ff00;
            transition: all 0.3s ease;
        }

        .hack-button:hover {
            box-shadow: 0 0 25px #00ff00;
            transform: scale(1.03);
        }

        .hack-button:disabled {
            background: #333333;
            border-color: #666666;
            color: #666666;
            cursor: not-allowed;
            box-shadow: none;
        }

        .hack-input {
            background: rgba(0, 0, 0, 0.9);
            border: 1px solid #00ff00;
            color: #00ff00;
            font-family: 'Share Tech Mono', monospace;
            transition: all 0.3s ease;
        }

        .hack-input:focus {
            box-shadow: 0 0 15px rgba(0, 255, 0, 0.4);
            outline: none;
        }

        .hack-input:disabled {
            background: #222222;
            color: #666666;
            border-color: #666666;
        }

        .glitch-text {
            position: relative;
            animation: glitch 1.5s infinite;
        }

        .glitch-text::before,
        .glitch-text::after {
            content: attr(data-text);
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
        }

        .glitch-text::before {
            animation: glitch-red 0.4s infinite;
            color: #ff0000;
            z-index: -1;
        }

        .glitch-text::after {
            animation: glitch-blue 0.4s infinite;
            color: #00ccff;
            z-index: -2;
        }

        @keyframes glitch {
            0%, 100% { transform: translate(0); }
            20% { transform: translate(-1px, -1px); }
            40% { transform: translate(1px, 1px); }
            60% { transform: translate(-1px, 1px); }
            80% { transform: translate(1px, -1px); }
        }

        @keyframes glitch-red {
            0%, 100% { transform: translate(0); }
            20% { transform: translate(-1px, -1px); }
            40% { transform: translate(1px, 1px); }
            60% { transform: translate(-1px, 1px); }
            80% { transform: translate(1px, -1px); }
        }

        @keyframes glitch-blue {
            0%, 100% { transform: translate(0); }
            20% { transform: translate(1px, 1px); }
            40% { transform: translate(-1px, -1px); }
            60% { transform: translate(1px, -1px); }
            80% { transform: translate(-1px, 1px); }
        }

        .error-message {
            border: 2px solid #ff0000;
            background: rgba(255, 0, 0, 0.1);
        }

        .success-message {
            border: 2px solid #00ff88;
            background: rgba(0, 255, 136, 0.1);
        }

        .info-box {
            background: rgba(0, 0, 0, 0.6);
            border-left: 4px solid #00ff00;
            padding: 10px 20px;
            margin: 20px 0;
            color: #00ff00;
            border-radius: 5px;
        }

        .hex-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 8px;
            margin-top: 30px;
            max-width: 600px;
            margin-left: auto;
            margin-right: auto;
        }

        .hex-cell {
            width: 100%;
            aspect-ratio: 1;
            border-radius: 5px;
            border: 2px solid #00ff00;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 14px;
            color: #00ff00;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .hex-cell:hover {
            box-shadow: 0 0 10px #00ff00;
        }

        .hex-cell:disabled {
            cursor: not-allowed;
            opacity: 0.5;
        }
    </style>
</head>
<body class="hacker-bg min-h-screen">
    <!-- Matrix Overlay -->
    <div class="matrix-overlay"></div>

    <!-- Main Container -->
    <div class="min-h-screen flex items-center justify-center p-8">
        <div class="terminal-glow rounded-lg w-full max-w-3xl p-10 terminal-scan relative">
            <!-- Header -->
            <div class="flex justify-between items-center mb-6 pb-4 border-b border-green-500">
                <div class="flex items-center space-x-3">
                    <div class="w-8 h-8 bg-red-500 rounded-full animate-pulse"></div>
                    <div>
                        <h1 class="glitch-text text-3xl font-bold text-green-400" data-text="CHALLENGE 8">CHALLENGE 8</h1>
                        <div class="text-green-300 text-sm">CYBERFLAG CTF</div>
                    </div>
                </div>
                <div class="text-right">
                    <div class="text-red-400 font-mono text-sm" id="systemTime">00:00:00</div>
                    <div class="text-green-300 text-xs">SYSTEM TIME</div>
                </div>
            </div>

            <!-- Timer and Points -->
            <div class="flex justify-between mb-6 text-green-400 font-mono">
                <div>Points: <span id="userPoints"><?php echo htmlspecialchars($user_points); ?></span></div>
                <div>🕒 Challenge Timer: <span id="challengeTimer"><?php echo htmlspecialchars($stored_time); ?></span></div>
            </div>

            <!-- Challenge Description -->
            <div class="mb-6">
                <h2 class="text-2xl text-green-400 mb-4">Hidden Hex Puzzle 🎨</h2>
                <p class="text-green-300">Hello, <?php echo htmlspecialchars($_SESSION['user_name']); ?>. The hex codes hide a secret sequence.</p>
                <p class="text-green-300">Enter the correct sequence of hex codes (e.g., <code class="bg-black/50 px-2 py-1 rounded">#464946,#413d3d,#3d413d,#666666</code>) to reveal the flag in the format <code class="bg-black/50 px-2 py-1 rounded">FLAG{....}</code>.</p>
            </div>

            <!-- Hints -->
            <div class="info-box">
                <strong>Hacker's Tip:</strong> The hex codes contain the key. Inspect the grid and find the correct sequence. Enter them comma-separated in the input below.
            </div>

            <!-- Hex Grid -->
            <div class="hex-grid" id="hexGrid">
                <div class="hex-cell" style="background-color: #ff5733;" data-hex="#ff5733">#ff5733</div>
                <div class="hex-cell" style="background-color: #464946;" data-hex="#464946">#464946</div>
                <div class="hex-cell" style="background-color: #aabbcc;" data-hex="#aabbcc">#aabbcc</div>
                <div class="hex-cell" style="background-color: #413d3d;" data-hex="#413d3d">#413d3d</div>
                <div class="hex-cell" style="background-color: #3d413d;" data-hex="#3d413d">#3d413d</div>
                <div class="hex-cell" style="background-color: #666666;" data-hex="#666666">#666666</div>
                <div class="hex-cell" style="background-color: #abcdef;" data-hex="#abcdef">#abcdef</div>
                <div class="hex-cell" style="background-color: #123456;" data-hex="#123456">#123456</div>
            </div>

            <!-- Input Form -->
            <div class="mt-6 flex flex-col items-center w-full max-w-md mx-auto">
                <!-- Input Field -->
                <input type="text" 
                    id="sequenceInput" 
                    class="hack-input px-4 py-3 rounded-lg w-full text-lg border-2 border-gray-300 focus:outline-none focus:ring-2 focus:ring-green-400 focus:border-green-500 transition-all duration-200"
                    placeholder="Enter sequence " 
                    <?php echo $challenge_completed ? 'disabled' : ''; ?>>

                <!-- Submit Button -->
                <button id="submitButton" 
                        class="hack-button mt-6 px-6 py-3 rounded-lg font-bold text-white bg-green-400 hover:bg-green-500 focus:outline-none focus:ring-4 focus:ring-green-300 disabled:bg-gray-300 disabled:text-gray-500 disabled:cursor-not-allowed transition-all duration-200"
                        <?php echo $challenge_completed ? 'disabled' : ''; ?>>Submit Sequence</button>
            </div>

            <!-- Feedback -->
            <?php if ($feedback): ?>
            <div id="feedbackMessage" class="<?php echo $feedback_color === '#00ff88' ? 'success-message' : 'error-message'; ?> rounded-lg p-4 mt-6">
                <p class="font-mono" style="color: <?php echo htmlspecialchars($feedback_color); ?>"><?php echo htmlspecialchars($feedback); ?></p>
            </div>
            <?php else: ?>
            <div id="feedbackMessage" class="error-message rounded-lg p-4 mt-6 hidden">
                <p class="font-mono"></p>
            </div>
            <?php endif; ?>

            <!-- Next Challenge Link -->
            <div id="nextChallenge" class="mt-6 text-center <?php echo $challenge_completed ? '' : 'hidden'; ?>">
                <a href="challenge9.php" class="hack-button inline-block px-6 py-3 rounded-lg font-bold text-green-400">→ Proceed to Challenge 9</a>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <div class="fixed bottom-0 left-0 right-0 bg-black bg-opacity-80 border-t border-green-500 p-4 z-20">
        <div class="flex justify-between items-center text-green-400 font-mono text-sm">
            <div>© 2025 CYBERFLAG CTF</div>
            <div class="flex space-x-4">
                <span>USER: <span class="text-cyan-400"><?php echo htmlspecialchars($_SESSION['user_name']); ?></span></span>
                <span>STATUS: <span class="text-red-400">ACTIVE</span></span>
            </div>
        </div>
    </div>

    <script>
        // Console hint
        console.log("💡 Tip: Inspect the hex grid and find the correct sequence of hex codes.");

        // System time
        function updateSystemTime() {
            const now = new Date();
            document.getElementById('systemTime').textContent = now.toLocaleTimeString('en-US', {
                hour12: false,
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit'
            });
        }

        // Challenge timer
        let secondsSpent = <?php echo json_encode($initial_seconds); ?>;
        const challengeTimerDisplay = document.getElementById('challengeTimer');
        let timerRunning = <?php echo json_encode(!$challenge_completed); ?>;

        function updateTimer() {
            if (!timerRunning) return;
            secondsSpent++;
            const mins = Math.floor(secondsSpent / 60);
            const secs = secondsSpent % 60;
            const formattedTime = `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
            challengeTimerDisplay.textContent = formattedTime;
        }

        // Hex grid interaction
        const hexCells = document.querySelectorAll('.hex-cell');
        const sequenceInput = document.getElementById('sequenceInput');
        const submitButton = document.getElementById('submitButton');
        const feedbackMessage = document.getElementById('feedbackMessage');
        const feedbackText = feedbackMessage.querySelector('p');
        const nextChallenge = document.getElementById('nextChallenge');
        const isCompleted = <?php echo json_encode($challenge_completed); ?>;

        if (!isCompleted) {
            hexCells.forEach(cell => {
                cell.addEventListener('click', () => {
                    if (!timerRunning) return;
                    const hex = cell.dataset.hex;
                    const currentValue = sequenceInput.value;
                    sequenceInput.value = currentValue ? `${currentValue},${hex}` : hex;
                });
            });

            submitButton.addEventListener('click', () => {
                if (!timerRunning) return;
                const answer = sequenceInput.value.trim();
                const timeSpent = challengeTimerDisplay.textContent;

                fetch('challenge8.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ answer, time_spent: timeSpent })
                })
                .then(response => response.json())
                .then(data => {
                    feedbackMessage.className = data.color === '#00ff88' ? 'success-message rounded-lg p-4 mt-6' : 'error-message rounded-lg p-4 mt-6';
                    feedbackText.style.color = data.color;
                    feedbackText.textContent = data.message;
                    feedbackMessage.classList.remove('hidden');

                    if (data.success) {
                        timerRunning = false;
                        document.getElementById('userPoints').textContent = data.points;
                        nextChallenge.classList.remove('hidden');
                        sequenceInput.disabled = true;
                        submitButton.disabled = true;
                        hexCells.forEach(cell => {
                            cell.classList.add('disabled');
                            cell.style.pointerEvents = 'none';
                        });
                    }
                })
                .catch(error => {
                    console.error('Fetch error:', error);
                    feedbackMessage.className = 'error-message rounded-lg p-4 mt-6';
                    feedbackText.style.color = '#ff6666';
                    feedbackText.textContent = 'Error: Could not process submission.';
                    feedbackMessage.classList.remove('hidden');
                });
            });
        }

        // Initialize
        setInterval(updateSystemTime, 1000);
        if (timerRunning) {
            setInterval(updateTimer, 1000);
        }

        // Stop timer on page unload
        window.addEventListener('unload', () => {
            if (timerRunning) {
                timerRunning = false;
            }
        });
    </script>
</body>
</html>